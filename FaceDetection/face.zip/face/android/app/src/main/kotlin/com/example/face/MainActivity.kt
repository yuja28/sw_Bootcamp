package com.example.face

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
